import os
os.system('python3 make_Camembert.py')
os.system('python3 make_GraphLines.py')  