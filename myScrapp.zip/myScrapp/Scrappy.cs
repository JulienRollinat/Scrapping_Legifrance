using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using Newtonsoft;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;


namespace myScrapp
{
    class Scrappy
    {
        List<string> ListeDesLiens = new List<string>();        

        public void GoToPageDeRecherche(string AdresseDuSite, string ChampDeRecherche1, string ChampDeRecherche2, string Jour, string Mois, string Year)
        {           

            var driver = new FirefoxDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)); // Ici on utilise FireFox. Veuillez l'installer sur votre Pc si cela n'a pas été fait avant (au lien suivant : https://www.mozilla.org/fr/firefox/download/thanks/)

            driver.Navigate().GoToUrl(AdresseDuSite); // On va sur le site.

            Thread.Sleep(5000); // Thead.Sleep permet d'indiquer au programme d'attendre un temps donné (ici 5000 millisecondes soit 5 secondes). Cette indication permet de ralentir le programme et d'éviter ainsi les bugs liés à une connexion internet trop lente. Elle peut être supprimée ou modifiée.  

            Console.WriteLine("Lancement de Firefox !");

            var ElementSelectJour = driver.FindElement(By.XPath("//*[@id='champDateDecision1J']"));
            var SelectJour =  new SelectElement(ElementSelectJour);
            SelectJour.SelectByText(Jour);

            Mois = ValueOfMois(Mois);

            var ElementSelectMonth = driver.FindElement(By.XPath("//*[@id='champDateDecision1M']"));
            var SelectMonth =  new SelectElement(ElementSelectMonth);
            SelectMonth.SelectByText(Mois);

            driver.FindElement(By.XPath("//*[@id='champDateDecision1A']")).SendKeys(Year);

            driver.FindElement(By.XPath("//*[@id='champ7']")).SendKeys(ChampDeRecherche1); // On remplit le champ correspondant au premier paramètre de recherche.

            driver.FindElement(By.XPath("//*[@id='champ8']")).SendKeys(ChampDeRecherche2); // Le deuxième paramètre de recherche va se remplir.

            driver.FindElement(By.XPath("//*[@id='content_right']/div/div/div[3]/input[1]")).Click(); // On clique sur le bouton "rechercher".

            Console.WriteLine("On lance la recherche !");
            
            Thread.Sleep(5000);

            var ElementResultats = driver.FindElement(By.XPath("//*[@id='center']/h3"));

            string Resultats = ElementResultats.Text;

            if(!Resultats.Contains("aucun"))
            {                  
                bool PageSuivante = true;

                Console.WriteLine("");
                Console.WriteLine("On va lister tous les résultats pour cette recherche.");
                Console.WriteLine("");
                Console.WriteLine("En voici la liste :");

                int CountForClick = 0;

                do
                {
                    var NombreElements = driver.FindElements(By.XPath("//*[@id='center']/ol/li"));                 

                    for (int i = 1; i <= NombreElements.Count; i++)
                    {
                        var ElementLien = driver.FindElement(By.XPath("//*[@id='center']/ol/li[" + i + "]/a"));

                        string Lien = ElementLien.GetAttribute("href");

                        Console.WriteLine("     - " +Lien);

                        ListeDesLiens.Add(Lien);
                    }                   

                    if(driver.FindElements(By.XPath("//*[@id='result']/div[4]/ul/li")).Count == 2)
                    {                       
                      try
                      {
                            driver.FindElement(By.XPath("//*[@id='result']/div[4]/ul/li[2]/a")).Click();
                      }
                      catch
                      {
                            Console.WriteLine("Pas de lien vers une page suivante... On est sur la dernière page de résultats.");
                            PageSuivante = false;
                      }

                    }

                    if(driver.FindElements(By.XPath("//*[@id='result']/div[4]/ul/li")).Count == 3)
                    {
                        CountForClick++;   

                        if(CountForClick == 1)
                        {                        
                            driver.FindElement(By.XPath("//*[@id='result']/div[4]/ul/li[2]/a")).Click();                                                 
                            
                        }

                        if(CountForClick == 2)
                        {                        
                            driver.FindElement(By.XPath("//*[@id='result']/div[4]/ul/li[3]/a")).Click();                            
                            
                        }

                        if(CountForClick > 2)
                        {                        
                           Console.WriteLine("");
                           Console.WriteLine("Pas de lien vers une page suivante... On est sur la dernière page de résultats.");
                           Console.WriteLine("");
                           PageSuivante = false;
                        }
                    }

                    if(driver.FindElements(By.XPath("//*[@id='result']/div[4]/ul/li")).Count == 4)
                    {
                        CountForClick++;   

                        if(CountForClick == 1)
                        {
                            driver.FindElement(By.XPath("//*[@id='result']/div[4]/ul/li[2]/a")).Click();                                                                                                      
                        }

                        if(CountForClick == 2)
                        {
                            driver.FindElement(By.XPath("//*[@id='result']/div[4]/ul/li[3]/a")).Click();                            
                                                                        
                        }

                        if(CountForClick == 3)
                        {
                            driver.FindElement(By.XPath("//*[@id='result']/div[4]/ul/li[4]/a")).Click();                                                                                                   
                        }

                        if(CountForClick > 3)
                        {
                            Console.WriteLine("");
                            Console.WriteLine("Pas de lien vers une page suivante... On est sur la dernière page de résultats.");
                            Console.WriteLine("");
                            PageSuivante = false;                                                                            
                        }                
                       
                    }

                    if(driver.FindElements(By.XPath("//*[@id='result']/div[4]/ul/li")).Count == 5)
                    {
                        try
                        {
                            driver.FindElement(By.XPath("//*[@id='result']/div[4]/ul/li[5]/a")).Click();
                        }
                        catch
                        {
                            Console.WriteLine("");
                            Console.WriteLine("Pas de lien vers une page suivante... On est sur la dernière page de résultats.");
                            Console.WriteLine("");
                            PageSuivante = false;
                        }
                    }                          
                    

                Thread.Sleep(3000);

                }while(driver.FindElements(By.XPath("//*[@id='result']/div[4]/ul/li")).Count > 1 && PageSuivante == true);

                Console.WriteLine("");
                Console.WriteLine("Le Listing des résultats pour cette recherche est achevé.");
                Console.WriteLine("");

                driver.Close();

                GoToLien(ListeDesLiens, ChampDeRecherche1, ChampDeRecherche2, Jour, Mois, Year);
            }
            else
            {
               Console.WriteLine("");
               Console.WriteLine("Aucun résultat pour cette recherche ! ");
               Console.WriteLine("");

               driver.Close(); 

            }                                       
            
        }

        public void GoToLien(List<string> ListeDesLiens, string ChampDeRecherche1, string ChampDeRecherche2, string Jour, string Mois, string Year)
        {          

            Console.WriteLine("");
            Console.WriteLine("Maintenant à partir de la liste de résultats, on va demander au navigateur internet d'aller sur chacune des pages correspondantes.");
            Console.WriteLine("");

            Console.WriteLine("");
            Console.WriteLine("Dans la partie 'bureau' (desktop) de votre ordinateur. On crée un dossier qui receuillera nos résultats.");
            Console.WriteLine("");

            string GlobalDirectoryPath = CreateGlobalDirectory(ChampDeRecherche1, ChampDeRecherche2, Jour, Mois, Year);

            var driver = new FirefoxDriver(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));            
            
            for ( int i = 0; i < ListeDesLiens.Count; i++)
            {                          
                driver.Navigate().GoToUrl(ListeDesLiens[i]);

                Thread.Sleep(5000);

                Console.WriteLine("");
                Console.WriteLine("On est sur la page " + ListeDesLiens[i]);
                Console.WriteLine("");

                OpenQA.Selenium.IWebElement ElementTitre;
                OpenQA.Selenium.IWebElement Juges;
                OpenQA.Selenium.IWebElement ElementContenu;
                OpenQA.Selenium.IWebElement DataDeLaPage;
                OpenQA.Selenium.IWebElement ElementEcli;
                
                try
                {
                    ElementTitre = driver.FindElement(By.XPath("//*[@id='content']/h2"));

                }
                catch
                {
                    ElementTitre = driver.FindElement(By.XPath("//*[@id='content_false']/div/h3[2]"));
                    
                }

                try
                {
                    Juges = driver.FindElement(By.XPath("//*[@id='content_false']/div/strong[2]"));

                }
                catch
                {
                    Juges = driver.FindElement(By.XPath("//*[@id='content_false']/div/h3[2]"));

                }

                try
                {
                    ElementContenu = driver.FindElement(By.XPath("//*[@id='content_false']/div/contenu"));
                }
                catch
                {
                    ElementContenu = driver.FindElement(By.XPath("//*[@id='content_false']/div/h3[2]"));

                }

                try
                {
                    DataDeLaPage = driver.FindElement(By.XPath("//*[@id='content_false']/div"));

                }
                catch
                {
                    DataDeLaPage = driver.FindElement(By.XPath("//*[@id='content_false']/div/h3[2]"));
                }

                try
                {
                    ElementEcli = driver.FindElement(By.XPath("//*[@id='content_false']/div/b[1]"));

                }
                catch
                {
                    ElementEcli = driver.FindElement(By.XPath("//*[@id='content_false']/div/h3[2]"));

                }          
            

                saveData(ElementTitre, ElementContenu, GlobalDirectoryPath, DataDeLaPage, Juges, ElementEcli);

            }

            driver.Close();      
            
        }

        public string CreateGlobalDirectory(string ChampDeRecherche1, string ChampDeRecherche2, string Jour, string Mois, string Year)
        {
            string DesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            string NomDeDossier = "";

            if(!String.IsNullOrEmpty(ChampDeRecherche1))
            {
                NomDeDossier = NomDeDossier + ChampDeRecherche1 + "_";
            }

            if(!String.IsNullOrEmpty(ChampDeRecherche2))
            {
                NomDeDossier = NomDeDossier + ChampDeRecherche2;
            }

            if(!String.IsNullOrEmpty(Jour))
            {
                NomDeDossier = "_" + NomDeDossier + Jour;
            }

            if(!String.IsNullOrEmpty(Mois))
            {
                NomDeDossier = NomDeDossier + Mois + "_";
            }

            if(!String.IsNullOrEmpty(Year))
            {
                NomDeDossier = NomDeDossier + Year;
            }            

            string GlobalDirectoryPath = DesktopPath + "//" + "Recherche_Légifrance_" + NomDeDossier;

            Directory.CreateDirectory(GlobalDirectoryPath);            

            return GlobalDirectoryPath; 

        }       

        public void saveData(IWebElement ElementTitre , IWebElement ElementContenu, string GlobalDirectoryPath, IWebElement DataDeLaPage, IWebElement Juges, IWebElement ElementEcli)
        {
                       
            string Titre = ElementTitre.Text;

            string SpecificDirectory = CreateSpecificDirectory(Titre, GlobalDirectoryPath); //Création d'un dossier spécifique pour la décision en question.

            var TitreSplit = Titre.Split(",");

            string Juridiction = TitreSplit[0];

            string Date = "";

            for (int i = 0; i < TitreSplit.Length; i++)
            {   
                if(TitreSplit[i].ToString().Contains("janvier") || TitreSplit[i].ToString().Contains("février") || TitreSplit[i].ToString().Contains("mars") || TitreSplit[i].ToString().Contains("avril") || TitreSplit[i].ToString().Contains("mai")|| TitreSplit[i].ToString().Contains("juin") || TitreSplit[i].ToString().Contains("juillet") || TitreSplit[i].ToString().Contains("août") || TitreSplit[i].ToString().Contains("septembre") || TitreSplit[i].ToString().Contains("octobre") || TitreSplit[i].ToString().Contains("novembre") || TitreSplit[i].ToString().Contains("décembre"))
                {
                    Date = TitreSplit[i];
                }                
            }                 

            string NumeroRG = "";

            for (int i = 0; i < TitreSplit.Length; i++)
            {   
                if(TitreSplit[i].ToString().Contains("-") || TitreSplit[i].ToString().Contains("/"))
                {
                    NumeroRG = TitreSplit[i];
                }                
            }                 
            
            // Enregistrement du Json

            Json JsonObject = new Json();

            JsonObject.Juridiction = Juridiction.ToString();

            JsonObject.NumeroRG = NumeroRG.ToString();

            string Contenu = "";

            if (ElementContenu != null)
            {
               if(!ElementContenu.Text.Contains("Texte intégral"))
               {
                   Contenu = ElementContenu.Text;
               }
               else
               {
                   Contenu = "";
               }              
               
            } 

            JsonObject.ContenuDeLaDecision = Contenu;
            
            string CompositionDeLaJuridiction = "";

            if (Juges != null)
            {
               if(!Juges.Text.Contains("Texte intégral"))
               {
                   CompositionDeLaJuridiction = Juges.Text;
               }
               else
               {
                   CompositionDeLaJuridiction = "";
               }              
               
            }

            JsonObject.CompositionDeLaJuridiction = CompositionDeLaJuridiction;

            string Ecli = "";

            if (ElementEcli != null)
            {
                if(ElementEcli.Text.Contains("Texte intégral"))
                {
                    Ecli = ElementEcli.Text;
                }
                else
                {
                    Ecli = "";
                }
                
            }            

            JsonObject.NumeroECLI= Ecli;

            var DateSplit = Date.Split(" ");

            string jour = DateSplit[1].ToString();

            string mois = DateSplit[2].ToString();

            string année = DateSplit[3].ToString();

            JsonObject.date.jour = jour;

            JsonObject.date.mois = mois;

            JsonObject.date.année = année;

            Titre = Titre.Replace("'", "_");

            Titre = Titre.Replace(" ", "_");

            Titre = Titre.Replace(" ", "_");

            Titre = Titre.Replace(",", "_");

            Titre = Titre.Replace("/", "");    

            string json = JsonConvert.SerializeObject(JsonObject, Formatting.Indented);

            using (System.IO.StreamWriter Json = new System.IO.StreamWriter(SpecificDirectory + "\\" + Titre + ".json"))
            {
                Json.WriteLine(json);
                Console.WriteLine("");
                Console.WriteLine("Téléchargement du fichier Json de " + Titre + " effectué !");
                Console.WriteLine("");
            }

            // Enregistrement du File 

            string DataTexte = DataDeLaPage.Text;

             using (System.IO.StreamWriter Json = new System.IO.StreamWriter(SpecificDirectory + "\\" + Titre + ".txt"))
            {
                Json.WriteLine(DataTexte);
                Console.WriteLine("");
                Console.WriteLine("Téléchargement du fichier texte de " + Titre + " effectué!");
                Console.WriteLine("");
            }

        }

         public string CreateSpecificDirectory(string Titre, string GlobalDirectoryPath)
        {

            Titre = Titre.Replace("'", "_");

            Titre = Titre.Replace(" ", "_");

            Titre = Titre.Replace(",", "_");

            Titre = Titre.Replace("/", "");             

            string SpecificDirectory =  GlobalDirectoryPath + "//" + Titre;

            Directory.CreateDirectory(SpecificDirectory);

            return SpecificDirectory;

        }

        public string ValueOfMois(string Mois)
        {
            string MoisForSelect = "";
        
            if(Mois == "1")
            {
                MoisForSelect = "Janvier";
            }

            if(Mois == "2")
            {
                MoisForSelect = "Février";
            }

            if(Mois == "3")
            {
                MoisForSelect = "Mars";
            }

            if(Mois == "4")
            {
                MoisForSelect = "Avril";
            }

            if(Mois == "5")
            {
                MoisForSelect = "Mai";
            }

            if(Mois == "6")
            {
                MoisForSelect = "Juin";
            }

            if(Mois == "7")
            {
                MoisForSelect = "Juillet";
            }

            if(Mois == "8")
            {
                MoisForSelect = "Août";
            }

            if(Mois == "9")
            {
                MoisForSelect = "Septembre";
            }

            if(Mois == "10")
            {
                MoisForSelect = "Octobre";
            }

            if(Mois == "11")
            {
                MoisForSelect = "Novembre";
            }

            if(Mois == "12")
            {
                MoisForSelect = "Décembre";
            }

            return MoisForSelect;
        }

    }
}




