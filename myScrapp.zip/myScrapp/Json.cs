
namespace myScrapp
{
    class Json
    {
        public Json()
        {
            date = new Date();
        }
        public string Juridiction { get; set; } = "";
        public string NumeroRG { get; set; } = "";
        public string NumeroECLI { get; set; } = "";
        public string ContenuDeLaDecision { get; set; } = "";
        public string CompositionDeLaJuridiction { get; set; } = "";
        public Date date { get; set; }        

    }
}