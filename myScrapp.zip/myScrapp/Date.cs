
namespace myScrapp
{
    class Date
        {
            public string jour { get; set; } = "";
            public string mois { get; set; } = "";
            public string année { get; set; } = "";
        }

}