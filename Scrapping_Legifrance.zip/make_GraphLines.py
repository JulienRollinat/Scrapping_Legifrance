import matplotlib.pyplot as plt
import numpy as np

path = "Graphiques/Array_synthesis.csv"

years = []
csv = []
with open(path) as file_in:    
    for line in file_in:
        arrLine = line.split(',')
        years.append(arrLine[0])
        csv.append(line)

years = list(set(years))
years.sort()

rejetTotal = []
cassationTotal = []

for year in years:
    rejetTotal.append(0)
    cassationTotal.append(0)

for year in years:
    for c in csv:    
        if year in c:               
            if "CASSATION" in c:
                cassationTotal[years.index(year)] += 1
            if "REJET" in c:
                rejetTotal[years.index(year)] += 1


plt.plot(years, rejetTotal, label="Rejet du pourvoi")
plt.plot(years, cassationTotal, label="Cassation")
plt.title('Analyse de la jurisprudence de la Cour de Cassation')
plt.legend(['Rejet du pourvoi','Cassation'])
plt.xlabel("Années")
plt.ylabel("Nombre d'occurences")
plt.savefig("Graphiques/Graphique_Analyse_Cour_de_Cassation.png", dpi = 150)