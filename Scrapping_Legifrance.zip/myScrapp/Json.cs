
namespace myScrapp
{
    class Json
    {
        public Json()
        {
            date = new Date();
        }
        public string Juridiction { get; set; } = "";
        public string Numero_RG { get; set; } = "";
        public string Numero_ECLI { get; set; } = "";
        public string Contenu_de_la_Decision { get; set; } = "";
        public string Composition_de_la_juridiction { get; set; } = "";
        public string Succes_du_pourvoi { get; set; } = "";
        public Date date { get; set; }        

    }
}