﻿using System;
using System.IO;
using System.Diagnostics;
using System.Text;
using System.Collections.Generic;
using System.Linq;

namespace myScrapp
{
    class Program
    {
        static void Main()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;

            Console.WriteLine("-----------------------------------------------------Welcome à toi Juriste Data !---------------------------------------------------------");
            Console.WriteLine("------------------------------------------------------------------------------------------------------------------------------------------");

            Console.WriteLine("Bienvenue sur ce petit programme de scrapping permettant de scrapper le site LEGIFRANCE.GOUV.FR");
            Console.WriteLine("");

            string Chrome = "";

            while (Chrome != "OUI")
            {

                Console.WriteLine("Ce programme ne fonctionne qu'avec Google Chrome.");
                Console.WriteLine("Avez-vous installé, et MIS A JOUR, Google Chrome sur votre ordinateur (deux réponses possibles : OUI ou NON)?");

                Chrome = Console.ReadLine();

                if (Chrome != "OUI" && Chrome != "NON")
                {
                    Console.WriteLine("");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Veuillez taper l'une des réponses possibles en majuscules (OUI ou NON).");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("");
                }

                if (Chrome == "NON")
                {
                    Console.WriteLine("");
                    Console.WriteLine("Désolé mais va falloir installer Firefox si tu veux m'utiliser ;)");
                    Console.WriteLine("");
                }
            }

            Console.WriteLine("");
            Console.WriteLine("Super ! On commence le paramétrage de ta recherche sur Légifrance...");
            Console.WriteLine("");

            string TypeOfSearch = "";

            while (TypeOfSearch != "keyword" && TypeOfSearch != "date" && TypeOfSearch != "deux")
            {

                Console.WriteLine("Souhaites-tu faire une recherche : ");
                Console.WriteLine(" - par mots clés (exemple: recherche des décisions pour le mot 'Lacoste', dans ce cas tu dois répondre par le mot clé : 'keyword') ? ");
                Console.WriteLine(" - par date de la décision (exemple: recherche des décisions du 15 avril 2017, dans ce cas tu dois répondre par le mot clé : 'date')) ?");
                Console.WriteLine(" - ou par une combinaison de ces deux critères (dans ce cas tu dois répondre par le mot clé :'deux'?)");

                TypeOfSearch = Console.ReadLine();

                if (TypeOfSearch != "keyword" && TypeOfSearch != "date" && TypeOfSearch != "deux")
                {
                    Console.WriteLine("");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Veuillez taper l'une des réponses possibles sans majuscules (keyword, date ou deux)");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("");
                }
            }

            string ChampDeRecherche1 = "";
            string ChampDeRecherche2 = "";

            if (TypeOfSearch == "keyword" || TypeOfSearch == "deux")
            {
                Console.WriteLine("");
                Console.WriteLine("Veuillez renseigner un mot clé servant à votre recherche (A défaut, tapez juste sur la touche Entrée).");
                ChampDeRecherche1 = Console.ReadLine();

                Console.WriteLine("");
                Console.WriteLine("Veuillez renseigner un second mot clé (A défaut, tapez juste sur la touche Entrée) ?");
                ChampDeRecherche2 = Console.ReadLine();
            }

            string Jour = "";
            string Mois = "";
            string Year = "";

            if (TypeOfSearch == "date" || TypeOfSearch == "deux")
            {
                int DateDuJour = 0;
                bool CorrectDay = false;
                while (!CorrectDay)
                {
                    Console.WriteLine("Quel est le jour de la décision (Réponse possible de 1 à 31, si vous ne la connaissez pas, tapez juste sur la touche Entrée) ");

                    Jour = Console.ReadLine();

                    DateDuJour = Int32.Parse(Jour);

                    if (DateDuJour >= 1 && DateDuJour <= 31)
                    {
                        CorrectDay = true;
                    }
                    else
                    {
                        Console.WriteLine("");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Veuillez taper l'une des réponses possibles (de 1 à 31)");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("");
                    }
                }

                int MoisDecision = 0;
                bool CorrectMonth = false;
                while (!CorrectMonth)
                {

                    Console.WriteLine("Quel est le mois de la décision (Réponse possible de 1 à 12, si vous ne le connaissez pas, tapez juste sur la touche Entrée) ");

                    Mois = Console.ReadLine();

                    MoisDecision = Int32.Parse(Mois);

                    if (MoisDecision >= 1 && MoisDecision <= 12)
                    {
                        CorrectMonth = true;
                    }
                    else
                    {
                        Console.WriteLine("");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Veuillez taper l'une des réponses possibles (de 1 à 12)");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("");
                    }
                }

                int YearDecision = 0;
                bool CorrectYear = false;
                while (!CorrectYear)
                {

                    Console.WriteLine("Quel est l'annnée de la décision (Réponse possible de 1900 à 2019, si vous ne la connaissez pas, tapez juste sur la touche Entrée) ");

                    Year = Console.ReadLine();

                    YearDecision = Int32.Parse(Year);

                    if (YearDecision >= 1900 && YearDecision <= 2019)
                    {
                        CorrectYear = true;
                    }
                    else
                    {
                        Console.WriteLine("");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Veuillez taper l'une des réponses possibles (de 1900 à 2019)");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("");

                    }

                }

            }

            Console.WriteLine("");
            Console.WriteLine("Souhaitez-vous que le programme sélectionne les décisions contenant un mot clé ? Si oui, lequel ? (A défaut, tapez juste sur la touche Entrée).");
            string KeyWord1 = Console.ReadLine();

            Console.WriteLine("************************************************************************************************************************************");
            Console.WriteLine(" C'est parti ! ");
            Console.WriteLine("");
            Console.WriteLine(" Le scrapping est en cours y a plus qu'à regarder l'ordinateur travailler ;) ");

            Scrappy Go = new Scrappy();
            Go.GoToPageDeRecherche("https://www.legifrance.gouv.fr/initRechJuriJudi.do", ChampDeRecherche1, ChampDeRecherche2, Jour, Mois, Year, KeyWord1); // Ici on lance le programme  de scrapping qui se trouve dans le fichier Scrappy.cs. Dans les parenthèses, on indique, dans l'ordre, le nom du site que l'on souhaite scrapper puis les deux paramètres de recherche souhaités.
            // Nb : Ce programme a été créé pour scrapper le site legifrance.gouv.fr, il ne pourrait pas fonctionné pour un autre site sans une refonte d'une grande partie du code.

            Console.WriteLine("************************************************************************************************************************************");
            Console.WriteLine(" C'est fini ! ");
            Console.WriteLine("************************************************************************************************************************************"); */

            Tools.cleanArray();

        }        

    }
}



