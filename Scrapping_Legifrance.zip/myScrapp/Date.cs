
namespace myScrapp
{
    class Date
        {
            public string day { get; set; } = "";
            public string month { get; set; } = "";
            public string year { get; set; } = "";
        }

}