using System;
using System.IO;
using System.Diagnostics;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace myScrapp
{
    public static class Tools
    {
        public static void cleanArray()
        {
            if (File.Exists(@"Graphiques\Array_synthesis.csv"))
            {
                var lines = File.ReadAllLines(@"Graphiques\Array_synthesis.csv");
                var newLines = new List<string>();

                foreach (var line in lines)
                {                    
                    if (Regex.IsMatch(line, "[0-9]"))
                    {
                        newLines.Add(line);
                    }
                }

                File.Delete(@"Graphiques\Array_synthesis.csv");

                foreach (var line in newLines)
                {
                   using (System.IO.StreamWriter csv = new System.IO.StreamWriter(@"Graphiques\Array_synthesis.csv", true))
                   {
                        csv.WriteLine(line);
                   } 
                }
            }
        }
    }
}