import os
os.system('python3 make_Camembert.py')
os.system('python3 make_GraphLines.py')
os.system('python make_Camembert.py')
os.system('python make_GraphLines.py')    