import csv
import matplotlib.pyplot as plt

path = "Graphiques/Array_synthesis.csv"

with open(path) as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=',')

    dates = []
    nbrejet = 0
    nbcasse = 0
    for row in csv_reader:
        dates.append(f"{row[0]}")
        if f"{row[1]}" == "REJET DU POURVOI":
            nbrejet += 1 
        if f"{row[1]}" == "CASSATION":
            nbcasse += 1

moins = min(dates, key=float)
plus = max(dates, key=float)

labels = "Cassation", "Rejet"

sizes = [nbcasse, nbrejet]
explode = (0, 0.1)

fig1, ax1 = plt.subplots()
ax1.pie(sizes, explode=explode, labels=labels, autopct='%1.1f%%', shadow=False, startangle=90)
ax1.axis('equal')

plt.title("Nombre de rejets et de cassations entre " + moins + " et " + plus)
plt.savefig("Graphiques/Diagramme_circulaire_Cour_de_Cassation.png", dpi = 150)